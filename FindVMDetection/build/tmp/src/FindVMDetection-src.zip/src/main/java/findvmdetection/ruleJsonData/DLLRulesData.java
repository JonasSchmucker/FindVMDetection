package findvmdetection.ruleJsonData;

import java.util.ArrayList;
import java.util.List;

public class DLLRulesData{
	public String dllName;
	public List<FunctionRulesData> functions = new ArrayList<>();
}