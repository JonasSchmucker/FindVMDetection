package findvmdetection.ruleJsonData;


public class ParameterRulesData{
	public int paramOrdinal;
	public String forbiddenValue;
	public String paramType;
}