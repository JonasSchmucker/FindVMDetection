package findvmdetection;

/**
 * @author Jonas Schmucker
 *
 */
public class FindVMDetectionMutexSemaphoresPortsStrategy implements FindVMDetectionAnalyzingStrategyInterface {

	@Override
	public boolean step() {
		// TODO Auto-generated method stub
		return false;
	}

}
