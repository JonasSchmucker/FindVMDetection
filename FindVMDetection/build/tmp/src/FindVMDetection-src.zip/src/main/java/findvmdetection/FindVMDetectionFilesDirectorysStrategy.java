package findvmdetection;

/**
 * 
 * @author Jonas Schmucker
 *
 */
public class FindVMDetectionFilesDirectorysStrategy implements FindVMDetectionAnalyzingStrategyInterface {

	@Override
	public boolean step() {
		// TODO Auto-generated method stub
		return false;
	}

}
