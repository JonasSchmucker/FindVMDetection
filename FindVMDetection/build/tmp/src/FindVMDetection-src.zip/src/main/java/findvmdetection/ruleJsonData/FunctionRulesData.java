package findvmdetection.ruleJsonData;

import java.util.ArrayList;
import java.util.List;

public class FunctionRulesData{
	public String functionName;
	public List<ParameterRulesData> parameters = new ArrayList<>();
}